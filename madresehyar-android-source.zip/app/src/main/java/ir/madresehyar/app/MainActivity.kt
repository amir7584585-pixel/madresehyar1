package ir.madresehyar.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val students = mutableListOf("علی رضایی", "زهرا محمدی", "امیر احمدی")
    private val attendance = mutableMapOf<String, String>()
    private val grades = mutableMapOf<String, String>()
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun page(title: String) {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            setBackgroundColor(0xFFF4F6FA.toInt())
        }
        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)
        val heading = TextView(this).apply {
            text = title
            textSize = 24f
            setTextColor(0xFF173B86.toInt())
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
            setPadding(0, dp(8), 0, dp(18))
        }
        root.addView(heading)
    }

    private fun button(label: String, action: () -> Unit) {
        val b = Button(this).apply {
            text = label
            textSize = 16f
            isAllCaps = false
            setOnClickListener { action() }
        }
        root.addView(b, LinearLayout.LayoutParams(-1, dp(54)).apply {
            bottomMargin = dp(10)
        })
    }

    private fun info(text: String) {
        root.addView(TextView(this).apply {
            this.text = text
            textSize = 16f
            setTextColor(0xFF263238.toInt())
            gravity = Gravity.RIGHT
            setPadding(0, dp(8), 0, dp(8))
        })
    }

    private fun showHome() {
        page("مدرسه‌یار")
        info("سامانه مدیریت مدرسه")
        info("نسخه آزمایشی اندروید ۱.۰")
        button("دانش‌آموزان") { showStudents() }
        button("حضور و غیاب") { showAttendance() }
        button("ثبت نمرات") { showGrades() }
        button("گزارش‌ها") { showReports() }
        info("اطلاعات این نسخه فقط روی همین گوشی نگهداری می‌شود.")
    }

    private fun showStudents() {
        page("فهرست دانش‌آموزان")
        val input = EditText(this).apply {
            hint = "نام دانش‌آموز جدید"
            textSize = 16f
        }
        root.addView(input)
        button("افزودن دانش‌آموز") {
            val name = input.text.toString().trim()
            if (name.isNotEmpty()) {
                students.add(name)
                showStudents()
            } else Toast.makeText(this, "نام را وارد کن", Toast.LENGTH_SHORT).show()
        }
        students.forEachIndexed { i, name -> info("${i + 1}. $name") }
        button("بازگشت") { showHome() }
    }

    private fun showAttendance() {
        page("حضور و غیاب")
        info("برای هر دانش‌آموز وضعیت را انتخاب کن.")
        students.forEach { name ->
            info(name)
            val choices = listOf("حاضر", "غایب", "تأخیر", "موجه")
            val spinner = Spinner(this)
            spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, choices)
            val old = choices.indexOf(attendance[name]).let { if (it < 0) 0 else it }
            spinner.setSelection(old)
            root.addView(spinner)
            spinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
                override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                    attendance[name] = choices[position]
                }
            }
        }
        button("ذخیره وضعیت‌ها") {
            Toast.makeText(this, "وضعیت‌ها در حافظه همین اجرا ثبت شد", Toast.LENGTH_SHORT).show()
        }
        button("بازگشت") { showHome() }
    }

    private fun showGrades() {
        page("ثبت نمرات")
        students.forEach { name ->
            info(name)
            val input = EditText(this).apply {
                hint = "نمره از ۲۰"
                inputType = 2
                setText(grades[name] ?: "")
            }
            root.addView(input)
            button("ذخیره نمره $name") {
                val value = input.text.toString().trim()
                val number = value.toFloatOrNull()
                if (number != null && number in 0f..20f) {
                    grades[name] = value
                    Toast.makeText(this, "نمره ذخیره شد", Toast.LENGTH_SHORT).show()
                } else Toast.makeText(this, "نمره باید بین ۰ تا ۲۰ باشد", Toast.LENGTH_SHORT).show()
            }
        }
        button("بازگشت") { showHome() }
    }

    private fun showReports() {
        page("گزارش‌ها")
        info("گزارش حضور و غیاب")
        students.forEach { info("$it: ${attendance[it] ?: "ثبت نشده"}") }
        info("گزارش نمرات")
        students.forEach { info("$it: ${grades[it] ?: "ثبت نشده"}") }
        button("بازگشت") { showHome() }
    }
}
